tinyMCE.addI18n('ca.modxlink',{
    link_desc:"Insert/edit link"
});