tinyMCE.addI18n('hu.modxlink',{
    link_desc:"Insert/edit link"
});