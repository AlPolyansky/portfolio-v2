tinyMCE.addI18n('mn.modxlink',{
    link_desc:"Insert/edit link"
});